import React from "react";
import Landing from './components/Landing'

function App() {
  return (
    <div className="App">
      <Landing />
    </div>
  );
}

export default App;
