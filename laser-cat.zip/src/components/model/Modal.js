import { useState } from "react";
import "./modal.css";

function Modal() {
  return <>
        
  </>;
}

export default Modal;
