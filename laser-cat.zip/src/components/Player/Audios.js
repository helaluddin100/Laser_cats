exports.songsdata = [
    {
        "title": "Omniverse theme",
        "url": "https://lasercats.io/static/media/SMOBLE_LS_OmniverseTheme 0313.mp3"
    },
    {
        "title": "Aris",
        "url": "https://lasercats.io/static/media/LC_RockTheme_ArisII.mp3"
    }

]