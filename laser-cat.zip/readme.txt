Make a component for a functionality (eg. mint):
1. Add the mint.js file to components folder.
2. Make a mint.scss file for the component and put it in styles folder.
3. Add a path to the component /mint in index.js.
4. Put art in assets folder.

npm installs:
1. react-router-dom
2. material-ui
3. react-responsive-spritesheet